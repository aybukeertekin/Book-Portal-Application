import React from "react";
import Login from "./Login";
import UserPage from "./UserDashboard";
import BookPage from "./BookDashboard";
import EditUser from "./EditUser.js";
import EditBook from "./EditBook.js";
import Home from "./Home.js";
import 'react-toastify/dist/ReactToastify.css';
import {
  BrowserRouter as Router,
  Switch,
  Route,
} from "react-router-dom";
import Menu from "./Menu";
import "../css/App.css";


class App extends React.Component{

  constructor(props){
    super(props);
      this.state = {
    };
  }

  isAuthenticated = () => {
    if(localStorage.getItem("isAuthenticated")){
      return true;
    }
    else 
      return false;
  }

  isAdmin = () => {
    if(localStorage.getItem("isAdmin")){
      return true;
    }
    else 
      return false;
  }

  menu = () => {
    return(
    <div style={{
      backgroundColor:"teal"}}>
        <Menu/>
    </div>);
  }

render = () => {
    return(
      <Router>
           <div>
           <Switch>   
           <Route exact path="/">
             <Login/>
            </Route>
            <Route exact path="/home">
                {this.menu()}
                <Home/>
            </Route>
            <Route path="/books">
              {this.menu()}         
              <BookPage/>
            </Route>
            <Route exact path="/authors">
              {this.menu()}
              <BookPage/>
            </Route>
            <Route exact path="/users">
              {this.menu()}
              <UserPage/>
            </Route>
            <Route exact path="/edit-user/:id">
                 <EditUser/>
            </Route>
            <Route exact path="/add-user">
              <EditUser isNew/>
            </Route>
            <Route exact path="/edit-book/:id">
               <EditBook/>            
            </Route>
            <Route exact path="/add-book">
              <EditBook isNew/>
            </Route>
            <Route exact path="/read-list">
              {this.menu()}
              <BookPage/>
            </Route>
            <Route exact path="/favorites">
              {this.menu()}
              <BookPage/>
            </Route>
            <Route path="*">
              <strong>Aradığınız sayfayı bulamadık!</strong>
            </Route>
          </Switch>
          </div>
      </Router>
    );
   }
  }

  export default App;
  