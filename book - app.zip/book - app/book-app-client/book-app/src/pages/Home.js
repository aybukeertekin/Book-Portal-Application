import React from 'react'
import 'react-toastify/dist/ReactToastify.css';
import "../css/App.css";
import hcbgImage from "../assets/background2.jpg";
import {
    withRouter
  } from "react-router-dom";

class Home extends React.Component{

    constructor(props){
        super(props);
        this.state = {
        };
    }

    render = () => {
        return (
        <div
            style={{
              backgroundImage: 'url('+hcbgImage+')',
              height: "100vh",
              color: "#f5f5f5"
            }}
          >
            <br/>
            <h1 position>Welcome to Booklyst!</h1>
          </div>
        );
    } 

}

export default withRouter(Home);