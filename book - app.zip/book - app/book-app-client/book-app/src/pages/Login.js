import React from 'react';
import { Form, Button, Container, Grid, Divider, Header, Image } from "semantic-ui-react";
import '../css/App.css';
import { toast } from 'react-toastify';
import fetch from "isomorphic-unfetch";
import logo from '../assets/logo.gif';
import {
    withRouter
  } from "react-router-dom";

  class Login extends React.Component{
    constructor(props){
      super(props);
      this.state = {
        username: "",
        password: "",
        usernameError: null,
        passwordError: null, 
      };
    }

    componentDidMount = () => {
      if(localStorage.getItem("isAuthenticated"))
        this.props.history.push("/home");
      
    }


    handleChange = (e) => {
      const {currentTarget} = e;
      const {value, name} = currentTarget;
      this.setState({ [name]: value});
      this.setState({usernameError: null, passwordError: null, passwordRepeatedError: null})  
    }


    handleSubmit = (e) => {
        e.preventDefault();
    
        const {username, password} = this.state;
    
        if(username.length < 5 || password.length > 255){
          this.setState({
            usernameError: "Please check the username.", 
          });
          return;
        }
        if(password.length < 3  || password.length > 255){
          this.setState({
            passwordError: "Please check the password.", 
          });
          return;
        }

        this.fetchLoginData(username, password);
    }
  
    fetchLoginData = (username, password) => {
      const formData = new URLSearchParams();
      formData.append("username", username);
      formData.append("password", password);
  
      fetch("http://localhost:8081/login" , {
          method: "POST", 
          headers: {
            "Content-Type": "application/x-www-form-urlencoded",
            "Accept": "application/json"
          },
          body: formData,
          credentials: "include",
      })
        .then((r) => {
          if(r.ok){;
            return r;
          }
          if(r.status === 401 || r.status === 403 || r.status === 500){
            return Promise.reject(new Error(r.status + "Login is not successful. Please check username and password."));
          }
        })
        .then((r) => {
          return r.json();
        })
        .then(data => {
          localStorage.setItem("isAuthenticated", "true");
          if(data.isAdmin === true){
            localStorage.setItem("isAdmin", "true");
          }
          toast.success("You are logged in! You are directed to home page!")
          setTimeout(() => {
            this.props.history.push("/home");
          }, 3000);
        
        })
        .catch((e) => {
          toast.error(e.message);
        });
  
    }

    onImageChange = event => {
      event.preventDefault();
      if (event.target.files && event.target.files[0]) {
        this.setState({
          image: URL.createObjectURL(event.target.files[0]),
          raw: event.target.files[0],
        });
      }
    };

  render = () => {
    const {username, password, usernameError, passwordError} = this.state;
    return (
        <div className="Login">
        <Container >
            <Grid textAlign='center' >
 
            <Grid.Row centered style={{ height: '45vh'}}>
                <Grid.Column width={16}>
                <br/><br/>
                  <Image src={logo} alt="loading..." style={{ height: '55vh'}}/> 
                  </Grid.Column>
                  </Grid.Row>
                  <Grid.Row centered style={{ height: '60vh'}}>
                <Grid.Column width={8}>
                <Divider/>
                <Header fluid size= "huge" style={{color:"white", fontSize: "45px"}} textAlign='center'>
                    Log-in
                  </Header>
                <br/><br/>
                <Form 
                    size ="huge"
                    onSubmit={this.handleSubmit}
                    onReset={(event) => {
                    event.preventDefault();
                    this.setState({
                        username: "",
                        password: "",});
                    }}
                >
                    <Form.Field>
                    <Form.Input 
                        type="email" 
                        name="username" 
                        required 
                        value= {username} 
                        onChange={this.handleChange}
                        error={usernameError}
                        fluid icon='user' 
                        iconPosition='left' 
                        placeholder='E-mail address'
                        />
                    </Form.Field>
                    <Form.Field>
                    <Form.Input 
                        type="password" 
                        name="password" 
                        required 
                        value= {password} 
                        onChange={this.handleChange}
                        error={passwordError}
                        fluid
                        icon='lock'
                        iconPosition='left'
                        placeholder='Password'
                        />
                    </Form.Field>
                    <Form.Field>
                    </Form.Field>
                    <br/>
                    <Button.Group fluid size = "large" >
                    <Button style={{
                        backgroundColor:"#d45b5b", fontSize: "18px", color: "white"}} type="reset"> Reset </Button>
                    <Button type="submit" style={{fontSize: "18px", color: "black"}}> Login </Button>
                    </Button.Group>
                </Form> 
                <br/> 
                <Divider/>              
           </Grid.Column>
            </Grid.Row>
            </Grid>
            
        </Container>
        </div>
    );
  }

}
export default withRouter(Login);