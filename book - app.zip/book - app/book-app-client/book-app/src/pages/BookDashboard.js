import React from 'react';
import { Segment, Button, Container, Grid, Divider, Search, Header, Table, Icon, Label, Menu } from "semantic-ui-react";
import {withRouter} from "react-router-dom";
import { toast } from 'react-toastify';
import fetch from "isomorphic-unfetch";
import '../css/App.css';

class Dashboard extends React.Component{
  constructor(props){ 
    super(props);
    this.state = {
      page: {},
      books: {},
      favorites: [],
      readList: [],
      users: {},
      currentPage: 0,
      isAdmin: false,
      isLoading: false, results: [], value: '',
    };
  }

  componentDidMount = () => {
    if(localStorage.getItem("isAdmin")){
        this.setState({isAdmin: true});
    }
    if(!localStorage.getItem("isAuthenticated"))
      this.props.history.push("/");

    this.getBooks();
    this.getAllFavorites();
    this.getAllReadList();
  }

  getFavorites = () => {
    fetch("http://localhost:8081/book-portal/user/favorites?" + new URLSearchParams({pageNumber: this.state.currentPage}) , {
      method: "GET", 
      headers: {
        "Content-Type": "application/json",
      },
      credentials: "include",
    })
    .then((r) => {
      if(r.ok){
        return r;
      }
      if(r.status === 401 || r.status === 403 || r.status === 500){
        return Promise.reject(new Error(r.status));
      }
    })
    .then((r) => {
      return r.json();
    })
    .then((data) => {
      this.setState({books: data});
    })
    .catch((e) => {
      toast.error(e.message);
    });
  }

  getAllFavorites = () => {
    fetch("http://localhost:8081/book-portal/user/all-favorites", {
      method: "GET", 
      headers: {
        "Content-Type": "application/json",
      },
      credentials: "include",
    })
    .then((r) => {
      if(r.ok){
        return r;
      }
      if(r.status === 401 || r.status === 403 || r.status === 500){
        return Promise.reject(new Error(r.status));
      }
    })
    .then((r) => {
      return r.json();
    })
    .then((data) => {
      this.setState({favorites: data});
    })
    .catch((e) => {
      toast.error(e.message);
    });
  }

  getAllReadList = () => {
    fetch("http://localhost:8081/book-portal/user/all-read-list", {
      method: "GET", 
      headers: {
        "Content-Type": "application/json",
      },
      credentials: "include",
    })
    .then((r) => {
      if(r.ok){
        return r;
      }
      if(r.status === 401 || r.status === 403 || r.status === 500){
        return Promise.reject(new Error(r.status));
      }
    })
    .then((r) => {
      return r.json();
    })
    .then((data) => {
      this.setState({readList: data});
    })
    .catch((e) => {
      toast.error(e.message);
    });
  }

  getReadList = () => {
    fetch("http://localhost:8081/book-portal/user/read-list?" + new URLSearchParams({pageNumber: this.state.currentPage}) , {
      method: "GET", 
      headers: {
        "Content-Type": "application/json",
      },
      credentials: "include",
    })
    .then((r) => {
      if(r.ok){
        return r;
      }
      if(r.status === 401 || r.status === 403 || r.status === 500){
        return Promise.reject(new Error(r.status));
      }
    })
    .then((r) => {
      return r.json();
    })
    .then((data) => {
      this.setState({books: data});
    })
    .catch((e) => {
      toast.error(e.message);
    });
  }


  renderAuthors(book){
    const items = [];

    if(book && book.author){
        for(let i = 0; i < book.authors.length; i++){
          const author = book.authors[i];
          items.push(
          <>
            <Icon name = "pencil alternate"/>
            {author.name}
            <br/>
          </>
          )

        }
    }
  }

  deleteBook = (i) => {
    fetch("http://localhost:8081/book-portal/book/delete/" + i.id, {
      method: "GET", 
      headers: {
        "Content-Type": "application/json",
      },
      credentials: "include",
    })
    .then((r) => {
      if(r.ok){
        setTimeout(() => {
          this.getBooks();
          this.getAllFavorites();
          this.getAllReadList();
          
        }, 2000);
        toast.success("The book is deleted!");
        return r;
      }
      if(r.status === 401 || r.status === 403 || r.status === 500){
        return Promise.reject(new Error(r.status));
      }
    })
  }

  getBooks = () => {
    const path = this.props.location.pathname;
    if(path === "/books")
      this.getAllBooks();
    else if(path === "/read-list")
      this.getReadList();
    else if(path === "/favorites")
      this.getFavorites();
  }

  getAllBooks = () => {
    fetch("http://localhost:8081/book-portal/book?" + new URLSearchParams({pageNumber: this.state.currentPage}) , {
      method: "GET", 
      headers: {
        "Content-Type": "application/json",
      },
      credentials: "include",
    })
    .then((r) => {
      if(r.ok){
        return r;
      }
      if(r.status === 401 || r.status === 403 || r.status === 500){
        return Promise.reject(new Error(r.status));
      }
    })
    .then((r) => {
      return r.json();
    })
    .then((data) => {
      this.setState({books: data});
    })
    .catch((e) => {
      toast.error(e.message);
    });
  }


  changePageTo = (i) => {
    this.setState({currentPage: i}, this.getBooks);
  }

  addToReadList = (book) => {
    fetch("http://localhost:8081/book-portal/user/add-read-list/" + book.id , {
      method: "POST", 
      credentials: "include",
      headers: {
        'Content-Type': 'application/json',
      },
    })
    .then((r) => {
      if(r.ok){
        return r;
      }
      if(r.status === 401 || r.status === 403 || r.status === 500){
        return Promise.reject(new Error(r.status));
      }
    })
    .then((data) => {
      toast.info(data);
      this.getBooks();
      this.getAllFavorites();
      this.getAllReadList();
    })
    .catch((e) => {
      toast.error(e.message);
    });

  }

  addToFavorites = (book) => {
    fetch("http://localhost:8081/book-portal/user/add-favorites/" + book.id, {
      method: "POST", 
      credentials: "include",
      headers: {
        'Content-Type': 'application/json',
      },
    })
    .then((r) => {
      if(r.ok){
        return r;
      }
      if(r.status === 401 || r.status === 403 || r.status === 500){
        return Promise.reject(new Error(r.status));
      }
    })
    .then((r) => {
      alert(r);
      return r.json();
    })
    .then((data) => {
      toast.info(data);
    })
    .catch((e) => {
      toast.error(e.message);
    });
    window.location.reload();
  }

  getSearchResults = () => {
    const value = this.state.value;
    fetch("http://localhost:8081/book-portal/book/search/" + value , {
      method: "GET", 
      headers: {
        "Content-Type": "application/json",
      },
      credentials: "include",
    })
    .then((r) => {
      if(r.ok){
        return r;
      }
      if(r.status === 401 || r.status === 403 || r.status === 500){
        return Promise.reject(new Error(r.status));
      }
    })
    .then((r) => {
      return r.json();
    })
    .then((data) => {
      this.setState({isLoading:false, results: data});
    })
    .catch((e) => {
      toast.error(e.message);
    });
}

handleChange = (e, {value}) => {
  const state = value;
  this.setState({value: state});
  setTimeout(() => {
    if (this.state.value.length < 1) 
      return this.setState({isLoading: false, results: [], value: ''});
      this.getSearchResults();
  }, 300);

}
handleResultSelect = (e, { result }) => this.setState({ value: result.username })

  render = () => {

    if(this.props.page !== this.state.page)
      this.setState({page: this.props.page});

    const {books, readList, favorites, isAdmin} = this.state;

    return (
      <div className="App">
        <Container>
          <br/><br/>
            <Segment placeholder>
          <Grid columns={2} stackable textAlign='center'>
            {this.isAdmin === true && <Divider vertical>Or</Divider>}

            <Grid.Row verticalAlign='middle'>

              <Grid.Column>
                <Header icon>
                  <Icon name='search' />
                  Search Books
                </Header>

                <Search placeholder='Search books...' 
                            loading={this.state.isLoading}
                            resultRenderer = {this.resultRenderer}
                            onResultSelect={this.handleResultSelect}
                            onSearchChange={this.handleChange}
                            results={this.state.results}
                            value={this.state.value}
                />
              </Grid.Column>

              {this.state.isAdmin === true &&
              <Grid.Column>
                <Header icon>
                  <Icon name='book' />
                  Add New Book
                </Header>
                <Button color = "teal" onClick = { () => {
                  this.props.history.push("/add-book");
                } }>Create</Button>
              </Grid.Column>}

            </Grid.Row>
          </Grid>
        </Segment>
        <br/><br/>
        <Divider/>
        <br/><br/>
          <Grid textAlign='center' style={{ height: '56vh' }}>
            <Grid.Row columns = "equal" centered >
              <Grid.Column width={16}>
                <Header size = "huge" color="teal"> Books </Header>
                <Table celled>
                  <Table.Header>
                    <Table.Row>
                      <Table.HeaderCell> ID </Table.HeaderCell>
                      <Table.HeaderCell> Title </Table.HeaderCell>
                      <Table.HeaderCell> ISBN </Table.HeaderCell>
                      <Table.HeaderCell> Author </Table.HeaderCell>
                      <Table.HeaderCell> Type </Table.HeaderCell>
                      <Table.HeaderCell> Publisher (Year) </Table.HeaderCell>                     
                           {
                              isAdmin === true ? (<Table.HeaderCell> Edit / Delete </Table.HeaderCell>):
                              (<Table.HeaderCell> Add To Read List / Add to Favorites </Table.HeaderCell>)
                            } 
                    </Table.Row>
                  </Table.Header>

                  <Table.Body>
                    {
                      books && books.content
                       && books.content.map((value, index) => (
                        <Table.Row>
                          <Table.Cell>
                       <Label ribbon>{books.size * books.number + (index + 1)}</Label>
                          </Table.Cell>
                            {value.title}
                          <Table.Cell>
                            <Icon name = "barcode"/>
                            {value.isbn}
                          </Table.Cell>
                            <Table.Cell>
                            <Icon name = "pencil alternate"/>
                              {
                                value.author
                              }

                            </Table.Cell>

                            <Table.Cell>
                            <Icon name = "book"/>
                            {value.type}
                            </Table.Cell>

                            <Table.Cell>
                            <Icon name = "pagelines"/>
                            {value.publisher + "(" + value.year + ")"}
                            </Table.Cell>
                            {
                                (isAdmin === true ?            
                                (<Table.Cell textAlign="center"><Icon size = "large" name = "edit" onClick={ () => this.props.history.push("/edit-book/" + value.id)}/> <Icon  size = "large"  name = "delete" onClick={() => this.deleteBook(value)}/> </Table.Cell>):
                                (<Table.Cell textAlign='center' >
                                  <Icon.Group size = "large">
                                    {readList.some(book => book.id === value.id) && <Icon size="big" color='red' name='dont' /> }
                                    <Icon size = "large"  name = "book" onClick={ () =>  this.addToReadList(value)}/>
                                  </Icon.Group>
                                  <Icon.Group size = "large">
                                    {favorites.some(book => book.id === value.id) && <Icon size='big' color='red' name='dont' /> }
                                    <Icon  size = "large"  name = "like" onClick={() =>  this.addToFavorites(value)}></Icon>
                                  </Icon.Group>
                                </Table.Cell>))
                           }
                           
                        </Table.Row>             
                      ))}
                  </Table.Body>
                  <Table.Footer>
                    <Table.Row>
                      <Table.HeaderCell colSpan='7'>
                        <Menu floated='right' pagination>
                          <Menu.Item as='a' icon disabled = {books.first}
                            onClick = {() => {
                              this.changePageTo(this.state.currentPage - 1);
                            }
                          }
                          >
                          <Icon name='chevron left' />
                          </Menu.Item>

                          { 
                            [...Array(books.totalPages).keys()].map( 
                              (value, index) => (
                                <Menu.Item 
                                  as='a'                           
                                  onClick = {() => {
                                    this.changePageTo(index);
                                  }}
                                  active = {books.number === index}
                                >
                                {index + 1}
                                </Menu.Item>
                              )
                          )}                  
                          <Menu.Item as='a' icon disabled = {books.last}
                            onClick = {() => {
                              this.changePageTo(this.state.currentPage + 1);
                            }
                          }>
                            <Icon name='chevron right' />
                          </Menu.Item>
                        </Menu>
                      </Table.HeaderCell>
                    </Table.Row>
                  </Table.Footer>
                </Table>
              </Grid.Column>
            </Grid.Row>
          </Grid>
        </Container>
      </div>
    );
  };
}

export default withRouter(Dashboard);