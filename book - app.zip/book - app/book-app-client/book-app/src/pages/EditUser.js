import React from 'react';
import { Form, Button, Container, Grid, Divider, Image} from "semantic-ui-react";
import '../css/App.css';
import { toast } from 'react-toastify';
import fetch from "isomorphic-unfetch";
import {
    withRouter
  } from "react-router-dom";

  class EditUser extends React.Component{
    constructor(props){
      super(props);
      this.state = {
        username: "",
        password: "",
        name: "", 
        surname: "",
        repeatedPassword: "",
        usernameError: null,
        passwordError: null, 
        passwordRepeatedError: null,
        file: 'https://semantic-ui.com/images/wireframe/image.png',
        image: "",
        newUser: true,
      };
    }

    componentDidMount = () => {
      if(!localStorage.getItem("isAdmin"))
        this.props.history.push("/");

      if(!this.props.isNew){
        const id = this.props.match.params.id;
        fetch("http://localhost:8081/book-portal/user/" +  id, {
          method: "GET", 
          headers:{
            "Content-Type": "application/json",
          },
          credentials: "include",
      })
        .then((r) => {
          if(r.ok){
            return r;
          }
          if(r.status === 401 || r.status === 403 || r.status === 500){
            return Promise.reject(new Error(r.status + ": You do not have access to this page!"));
          }
        })
        .then((r) => r.json())
        .then((user) => {
          this.setState({newUser: false, username: user.username,
                        name: user.name, surname: user.surname})
          toast.success("The user is saved!");
        })
        .catch((e) => {
          toast.error(e.message);
        });

      }
    }

    handleChange = (e) => {
      const {currentTarget} = e;
      const {value, name} = currentTarget;
      this.setState({ [name]: value});
      this.setState({usernameError: null, passwordError: null, passwordRepeatedError: null})  
    }


    handleSubmit = (e) => {
        e.preventDefault();
    
        const {username, password, repeatedPassword} = this.state;
    
        if(username.length < 5 || password.length > 255){
          this.setState({
            usernameError: "Lütfen kullanıcı adını kontrol ediniz.", 
          });
          return;
        }
        if(password.length < 3  || password.length > 255){
          this.setState({
            passwordError: "Lütfen şifrenizi kontrol ediniz.", 
          });
          return;
        }

        if(password !== repeatedPassword){
        this.setState({
            passwordRepeatedError: "Şifreniz aynı değil.",
        });
          return;
        } 

        if(this.props.isNew){
          this.fetchRegisterData();
        }
        else {
          this.editUser();
          this.props.history.push("/users");
        }
    }
    
    editUser = () => {
      const id = this.props.match.params.id;
      const {password, name, surname} = this.state;
      fetch("http://localhost:8081/book-portal/user/" + id, {
          method: "PUT", 
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({password, name, surname}),
          credentials: "include",
      })
        .then((r) => {
          if(r.ok){
            return r;
          }
          if(r.status === 401 || r.status === 403 || r.status === 500){
            return Promise.reject(new Error(r.status));
          }
        })
        .then((r) => r.json())
        .then((user) => {
            toast.success("The user is updated successfully.");
        })
        .catch((e) => {
          toast.error(e.message);
        });
    }

    fetchRegisterData = () => {

      const {username, password, name, surname} = this.state;
      const image = new Uint32Array(this.state.image);

      const formData = new URLSearchParams();
      formData.append("username", username);
      formData.append("password", password);
      formData.append("name", name);
      formData.append("surname", surname);
      formData.append("image", image);

      fetch("http://localhost:8081/book-portal/user" , {
          method: "POST", 
          credentials: "include",
          body: formData,
          reportProgress: true,
      })
        .then((r) => {
          if(r.ok){
            return r;
          }
          if(r.status === 401 || r.status === 403 || r.status === 500){
            return Promise.reject(new Error(r.status));
          }
        })
        .then((user) => {
          this.reset();
          toast.success("The user is successfully saved. Do you want to add another user?");
        })
        .catch((e) => {
          toast.error(e.message);
        });
    }

    reset = () => {
      this.setState({
        username: "",
        password: "",
        name: "", 
        surname: "",
        repeatedPassword: "",
        usernameError: null,
        passwordError: null, 
        passwordRepeatedError: null,
        file: 'https://semantic-ui.com/images/wireframe/image.png',
        image: "",
      })
    }



    onImageChange = event => {
      event.preventDefault();
      if (event.target.files && event.target.files[0]) {
        this.setState({
          file: URL.createObjectURL(event.target.files[0]),
          image: event.target.files[0],
        });
      }
    }

    readFileDataAsBase64 = () => {
      const file = this.state.image;
  
      return new Promise((resolve, reject) => {
          const reader = new FileReader();
  
          reader.onload = (event) => {
              resolve(event.target.result);
          };
  
          reader.onerror = (err) => {
              reject(err);
          };
  
          reader.readAsDataURL(file);
      });
  }

  render = () => {
    const {username, password, name, surname, usernameError,  repeatedPassword, passwordError, passwordRepeatedError, file} = this.state;
    return (
        <div className="App">
        <Container >
            <Grid textAlign='center' style={{ height: '104vh'}} verticalAlign='middle'>
            <Grid.Row columns = "equal" centered>
                <Grid.Column width={8}>
                <Form 
                    onSubmit={this.handleSubmit}
                    enctype="multipart/form-data"
                    onReset={(event) => {
                    event.preventDefault();
                    this.setState({
                        username: "",
                        password: "",});
                    }}
                >
                    <Form.Field>
                      <Image name="myImage" src={file} alt="upload" size = "medium" centered/>
                      <br/><Divider/><br/>
                      <Form.Input type="file" onChange={this.onImageChange}>                      
                    </Form.Input>
                    </Form.Field>


                    <Form.Field>
                    <Form.Input 
                        type="email" 
                        name="username" 
                        required 
                        value= {username} 
                        onChange={this.handleChange}
                        error={usernameError}
                        fluid icon='user' 
                        iconPosition='left' 
                        placeholder='E-mail address'
                        disabled={!this.props.isNew}
                        />
                    </Form.Field>
                    <Form.Field>
                      <Form.Input 
                          type="text" 
                          name="name"
                          placeholder='Name'
                          value = {name}
                          fluid icon='user circle' 
                          iconPosition='left' 
                          required
                          onChange={this.handleChange}
                      />
                      </Form.Field>
                      <Form.Field>
                      <Form.Input 
                          type="text" 
                          name="surname"
                          value = {surname}
                          placeholder='Surname'                     
                          fluid icon='home' 
                          iconPosition='left'
                          required 
                          onChange={this.handleChange}
                      />
                      </Form.Field>
                    <Form.Field>
                    <Form.Input 
                        type="password" 
                        name="password" 
                        required 
                        value= {password} 
                        onChange={this.handleChange}
                        error={passwordError}
                        fluid
                        icon='lock'
                        iconPosition='left'
                        placeholder='Password'
                        />
                    </Form.Field>
                    <Form.Field>
                    </Form.Field>
              
                      <Form.Field>
                        <Form.Input
                          type="password" 
                          name="repeatedPassword" 
                          required 
                          value= {repeatedPassword} 
                          onChange={this.handleChange}
                          error = {passwordRepeatedError}
                          fluid
                          icon='lock'
                          iconPosition='left'
                          placeholder='Repeat Password'
                        />
                      </Form.Field>
                

                    <Divider/>
                    <Button.Group fluid size = "large">
                    <Button color="teal" type="reset" > Reset </Button>
                     <Button type="submit"> Save </Button>
                    </Button.Group>
                    <br/>
                    <br/>
                    <br/>
                    <br/>
                </Form>  
                <div>
                        <Button size="large" 
                                content='Back' 
                                icon='arrow circle left' 
                                labelPosition='left' 
                                color="olive"
                                onClick = { () => {
                                  this.props.history.push("/users");
                                }
                                }
                                /> 
                    </div>              
           </Grid.Column>
                
            </Grid.Row>
            </Grid>
            
        </Container>
        </div>
    );
  }

}
export default withRouter(EditUser);