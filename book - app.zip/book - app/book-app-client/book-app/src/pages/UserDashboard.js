import React from 'react';
import { Button, Container, Grid, Divider, Header, Segment, Table, Icon, Label, Menu, Search } from "semantic-ui-react";
import {withRouter} from "react-router-dom";
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import fetch from "isomorphic-unfetch";
import '../css/App.css';

class UserPage extends React.Component{
  constructor(props){ 
    super(props);
    this.state = {
      users: {},
      currentPage: 0,
      isLoading: false, results: [], value: '',
    };
  }

  componentDidMount = () => {
    if(!localStorage.getItem("isAdmin"))
      this.props.history.push("/");
    this.getUsers();
  }


  getUsers = () => {
    fetch("http://localhost:8081/book-portal/user?" + new URLSearchParams({pageNumber: this.state.currentPage}) , {
      method: "GET", 
      headers: {
        "Content-Type": "application/json",
      },
      credentials: "include",
    })
    .then((r) => {
      if(r.ok){
        return r;
      }
      if(r.status === 401 || r.status === 403 || r.status === 500){
        return Promise.reject(new Error(r.status));
      }
    })
    .then((r) => {
      return r.json();
    })
    .then((data) => {
      this.setState({users: data});
    })
    .catch((e) => {
      toast.error(e.message);
    });
  }

  getSearchResults = () => {
      const value = this.state.value;
      fetch("http://localhost:8081/book-portal/user/search?" + new URLSearchParams({username: value}) , {
        method: "GET", 
        headers: {
          "Content-Type": "application/json",
        },
        credentials: "include",
      })
      .then((r) => {
        if(r.ok){
          return r;
        }
        if(r.status === 401 || r.status === 403 || r.status === 500){
          return Promise.reject(new Error(r.status));
        }
      })
      .then((r) => {
        return r.json();
      })
      .then((data) => {
        this.setState({isLoading:false, results: data});
      })
      .catch((e) => {
        toast.error(e.message);
      });
  }

  handleChange = (e, {value}) => {
    const state = value;
    this.setState({value: state});
    setTimeout(() => {
      if (this.state.value.length < 1) 
        return this.setState({isLoading: false, results: [], value: ''});
        this.getSearchResults();
    }, 300);

  }

  handleResultSelect = (e, { result }) => this.setState({ value: result.username })


  changePageTo = (i) => {
    this.setState({currentPage: i}, this.getUsers);
  }

  deleteUser = (i) => {
    fetch("http://localhost:8081/book-portal/user/delete/" + i.id, {
      method: "GET", 
      headers: {
        "Content-Type": "application/json",
      },
      credentials: "include",
    })
    .then((r) => {
      if(r.ok){
        setTimeout(() => {
          window.location.reload();
        }, 2000);
        toast.success("The user is re/deactived.You can re/deactive it by pressing cross again!");
        return r;
      }
      if(r.status === 401 || r.status === 403 || r.status === 500){
        return Promise.reject(new Error(r.status));
      }
    })
  }

  resultRenderer =( content ) => {
    return(
        <div>
        <div style={{ background: 'red' }}>
          {content.username}
        </div>
      </div>
    );
  }

  render = () => {

    const {users} = this.state;
    return (
      <div className="App">
        <Container>
        <br/><br/>
            <Segment placeholder>
          <Grid columns={2} stackable textAlign='center'>
            <Divider vertical>Or</Divider>

            <Grid.Row verticalAlign='middle'>
              <Grid.Column>
                <Header icon>
                  <Icon name='search' />
                  Search Users
                </Header>
                <Search placeholder='Search users...' 
                            loading={this.state.isLoading}
                            resultRenderer = {this.resultRenderer}
                            onResultSelect={this.handleResultSelect}
                            onSearchChange={this.handleChange}
                            results={this.state.results}
                            value={this.state.value}
                />
              </Grid.Column>

              <Grid.Column>
                <Header icon>
                  <Icon name='book' />
                  Add a New User
                </Header>
                <Button color = "teal" onClick = { () => {
                  this.props.history.push("/add-user");
                } }>Create</Button>
              </Grid.Column>
            </Grid.Row>
          </Grid>
        </Segment>
        <Divider/>
        <br/><br/>
          <Grid textAlign='center' style={{ height: '62vh' }}>
            <Grid.Row columns = "equal" centered >
              <Grid.Column width={16}>
                <Header size = "huge"> Users </Header>
                <Table celled>
                  <Table.Header>
                    <Table.Row>
                      <Table.HeaderCell> ID </Table.HeaderCell>
                      <Table.HeaderCell> Name </Table.HeaderCell>
                      <Table.HeaderCell> Email </Table.HeaderCell>
                      <Table.HeaderCell textAlign = "right"> Edit / Delete </Table.HeaderCell>
                      <Table.HeaderCell textAlign = "right"> See ReadList / Favorites </Table.HeaderCell>
                    </Table.Row>
                  </Table.Header>

                  <Table.Body>
                    {
                      users && users.content
                       && users.content.map((value, index) => (
                        <Table.Row>
                          <Table.Cell>
                       <Label ribbon>{users.size * users.number + (index + 1)}</Label>
                          </Table.Cell>
                          <Table.Cell>
                          <Icon name = "user"/>
                            {value.name + " " + value.surname}
                         </Table.Cell>
                          <Table.Cell>
                            <Icon name = "mail"/>
                            {value.username}
                          </Table.Cell >
                              <Table.Cell textAlign='right'><Icon size = "large" name = "edit" disabled={value.active === false} onClick={() => {this.props.history.push("/edit-user/" + value.id)}}/>  <Icon textAlign='right' size="large" name = "delete" onClick={() => this.deleteUser(value)}/> </Table.Cell>
                              <Table.Cell textAlign='right'><Icon size = "large" name = "book" onClick={() => {this.props.history.push("/edit-user/" + value.id)}}/>  <Icon textAlign='right' size="large" name = "like" onClick={() => this.deleteUser(value)}/> </Table.Cell>
                            </Table.Row>             
                      ))}
                  </Table.Body>
                  <Table.Footer>
                    <Table.Row>
                      <Table.HeaderCell colSpan='5'>
                        <Menu floated='right' pagination>
                          <Menu.Item as='a' icon disabled = {users.first}
                            onClick = {() => {
                              this.changePageTo(this.state.currentPage - 1);
                            }
                          }
                          >
                          <Icon name='chevron left' />
                          </Menu.Item>

                          { 
                            [...Array(users.totalPages).keys()].map( 
                              (value, index) => (
                                <Menu.Item 
                                  as='a'                           
                                  onClick = {() => {
                                    this.changePageTo(index);
                                  }}
                                  active = {users.number === index}
                                >
                                {index + 1}
                                </Menu.Item>
                              )
                          )}                  
                          <Menu.Item as='a' icon disabled = {users.last}
                            onClick = {() => {
                              this.changePageTo(this.state.currentPage + 1);
                            }
                          }>
                            <Icon name='chevron right' />
                          </Menu.Item>
                        </Menu>
                      </Table.HeaderCell>
                    </Table.Row>
                  </Table.Footer>
                </Table>
              </Grid.Column>
            </Grid.Row>
          </Grid>
        </Container>
      </div>
    );
  };
}

export default withRouter(UserPage);