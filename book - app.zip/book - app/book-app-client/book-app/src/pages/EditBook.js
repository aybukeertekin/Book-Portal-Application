import React from 'react';
import { Form, Button, Container, Grid, Divider, Radio, Label } from "semantic-ui-react";
import '../css/App.css';
import { toast } from 'react-toastify';
import fetch from "isomorphic-unfetch";
import {
    withRouter
  } from "react-router-dom";

  class EditBook extends React.Component{
    constructor(props){
      super(props);
      this.state = {
        isbn: "",
        title: "",
        author: "",
        publisher: "",
        type: "", 
        year: null,
        ISBNerror: null,
        titleError: null,
        authorError: null,
        publisherError: null,
        yearError: null,
        typeError: null,
        newBook: true,
      };
    }

    resetState = () => {
      this.setState( {
        isbn: "",
        title: "",
        author: "",
        publisher: "",
        type: "", 
        year: null,
        ISBNerror: null,
        titleError: null,
        authorError: null,
        publisherError: null,
        yearError: null,
        typeError: null,
        newBook: true,
      });
    }

    componentDidMount = () => {
      if(!localStorage.getItem("isAdmin"))
        this.props.history.push("/");


      if(!this.props.isNew){
        const id = this.props.match.params.id;
        fetch("http://localhost:8081/book-portal/book/" +  id, {
          method: "GET", 
          headers:{
            "Content-Type": "application/json",
          },
          credentials: "include",
      })
        .then((r) => {
          if(r.ok){
            return r;
          }
          if(r.status === 401 || r.status === 403 || r.status === 500){
            return Promise.reject(new Error(r.status));
          }
        })
        .then((r) => r.json())
        .then((book) => {
          this.setState({newBook: false, isbn: book.isbn, title: book.title,
                          author: book.author, publisher: book.publisher,
                          type: book.type, year: book.publicationYear})
          toast.success("You have successfully registered! You are being redirected to Menu.");
        })
        .catch((e) => {
          toast.error(e.message);
        });
      }
    }

    handleChange = (e) => {
      const {currentTarget} = e;
      const {value, name} = currentTarget;
      this.setState({ [name]: value});
      //this.setState({usernameError: null, passwordError: null, passwordRepeatedError: null})  
    }


    handleSubmit = (e) => {
        e.preventDefault();
    
        const {isbn, title, author, publisher, type, year} = this.state;

    
        if(isbn.length !== 10 && isbn.length !== 13 && this.state.newBook === true){
          this.setState({
            ISBNerror: "ISBN should be a number of length 10 or 13.", 
          });
          return;
        }
        if(title.length < 1){
          this.setState({
            titleError: "The title cannot be blank.", 
          });
          return;
        }

        if(title.length > 255){
          this.setState({
            titleError: "The title is too long.", 
          });
          return;
        }

        if(author.length < 3 || author.length > 255){
          this.setState({
            authorError: "Please check the length of the author name.",
          });
          return;
        } 
        if(publisher.length < 3 || publisher.length > 255){
          this.setState({
            publisherError: "Please check the length of the publisher.",
          });
          return;
        }
        if(type === null){
          this.setState({
            typeError: "Please enter type of the book.",
          });
          return;
        }
        if(publisher.length < 3 || publisher.length > 255){
          this.setState({
            passwordRepeatedError: "Please check the length of the publisher.",
          });
          return;
        } 
        if(year > new Date().getFullYear()){
          this.setState({
            passwordRepeatedError: "The year you enter is not valid.",
          });
          return;
        }     
        //this.editBook();
        if(this.props.isNew){
          this.addBook();
          this.resetState();
        }
        else{
          this.updateBook(e);
          this.props.history.push("/books")
        }
    }

    addBook = () => {
      const {isbn, title, author, publisher, year, type} = this.state;
      fetch("http://localhost:8081/book-portal/book" , {
          method: "POST", 
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({isbn, title, author, publisher, type, year}),
          credentials: "include",
      })
        .then((r) => {
          if(r.ok){
            return r;
          }
          if(r.status === 401 || r.status === 403 || r.status === 500){
            return Promise.reject(new Error(r.status));
          }
        })
        .then((r) => r.json())
        .then((book) => {
            toast.success("The book is added successfully.");
        })
        .catch((e) => {
          toast.error(e.message);
        });
    }

    updateBook = (book) => {
      const id = this.props.match.params.id;
      const {title, author, publisher, year, type} = this.state;
      fetch("http://localhost:8081/book-portal/book/" + id, {
          method: "PUT", 
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({title, author, publisher, type, year}),
          credentials: "include",
      })
        .then((r) => {
          if(r.ok){
            return r;
          }
          if(r.status === 401 || r.status === 403 || r.status === 500){
            return Promise.reject(new Error(r.status));
          }
        })
        .then((r) => r.json())
        .then((book) => {
            toast.success("The book is updated successfully.");
        })
        .catch((e) => {
          toast.error(e.message);
        });
    }

    onImageChange = event => {
      event.preventDefault();
      if (event.target.files && event.target.files[0]) {
        this.setState({
          image: URL.createObjectURL(event.target.files[0]),
          raw: event.target.files[0],
        });
      }
    };

  radioButton = (name, value) => {
      return(
    <Form.Field>
    <Radio
        name='radioGroup'
        value={value}
        checked={this.state.type === value}
        onChange={this.handleRadioButtonChange}
    />
    <Label size="large">{name}</Label>
    </Form.Field>
      );
  }

  handleRadioButtonChange = (e, { value}) => {
    this.setState({type: value});
  }

  render = () => {
    const {isbn, title, author, publisher, type, year, ISBNerror, titleError, publisherError, authorError, yearError} = this.state;
    return (
        <div className="App">
        <Container >
            <Grid textAlign='center' style={{ height: '104vh'}} verticalAlign='middle'>
            <Grid.Row columns = "equal" centered>
                <Grid.Column width={8}>
                <Form 
                    onSubmit={this.handleSubmit}
                    onReset={(event) => {
                    event.preventDefault();
                    this.setState({
                        username: "",
                        password: "",});
                    }}
                >

                    <Form.Field>
                      <Form.Input 
                          type="number" 
                          name="isbn"
                          fluid icon='barcode' 
                          placeholder='ISBN Number'
                          iconPosition='left' 
                          required
                          value= {isbn} 
                          error={ISBNerror}
                          onChange={this.handleChange}
                          disabled={this.state.newBook === false}
                      />
                      </Form.Field>
                      <Form.Field>
                      <Form.Input 
                          type="text" 
                          name="title"
                          placeholder='Title'                     
                          fluid icon='home' 
                          iconPosition='left' 
                          required
                          value= {title} 
                          error={titleError}
                          onChange={this.handleChange}
                      />
                      </Form.Field>
                    <Form.Field>
                    <Form.Input 
                        type="text" 
                        name="author" 
                        required 
                        value= {author} 
                        onChange={this.handleChange}
                        error={authorError}
                        fluid icon='user' 
                        iconPosition='left' 
                        placeholder='Author'
                        />
                    </Form.Field>
                    <Form.Field>
                    <Form.Input 
                        type="text" 
                        name="publisher" 
                        required 
                        value= {publisher} 
                        onChange={this.handleChange}
                        error={publisherError}
                        fluid
                        icon='lock'
                        iconPosition='left'
                        placeholder='Publisher'
                        />
                    </Form.Field>
                    <Form.Field>
                    </Form.Field>
              
                      <Form.Field>
                        <Form.Input
                          type="year" 
                          name="year" 
                          required 
                          value= {year} 
                          onChange={this.handleChange}
                          error = {yearError}
                          fluid
                          icon='lock'
                          iconPosition='left'
                          placeholder='Publication Year'
                        />
                      </Form.Field>
                      <br/>
                      <Label size = "big">Book Type: </Label>
                      <br/><br/>
                      <Grid fluid>
                        <Grid.Row columns= "equal" centered>
                          <Grid.Column>
                      {
                          this.radioButton("novel", "NOVEL")
                          
                      }
                      {
                          this.radioButton("biography", "BIOGRAPHY")
                      }
                      {
                          this.radioButton("poetry", "POETRY")
                      }
                      </Grid.Column>
                      <Grid.Column>
                      {
                          this.radioButton("history", "HISTORY")
                      }
                      {
                          this.radioButton("travel", "TRAVEL")
                      }
                     {
                          this.radioButton("science", "SCIENCE")
                     }
                     </Grid.Column>
                     <Grid.Column>
                     {

                          this.radioButton("literary", "LITERARY")
                     }
                     {
                        
                          this.radioButton("art", "ART")
                     }
                     {
                          this.radioButton("memory", "MEMORY")
                      }
                      </Grid.Column>
                      </Grid.Row>
                      </Grid>
                    <Divider/>
                    <Button.Group fluid size = "large">
                    <Button color="teal" type="reset"> Reset </Button>
                     <Button type="submit"> Save </Button>
                    </Button.Group>
                    <br/>
                    <br/>
                    <br/>
                    <br/>

                </Form>       
                  <Button 
                    size="large" 
                    content='Back' 
                    icon='arrow circle left' 
                    labelPosition='left' 
                    color="olive"
                    onClick = { () => {
                      this.props.history.push("/books");
                    }
                    }
                    /> 
           </Grid.Column>
                
            </Grid.Row>
            </Grid>
            
        </Container>
        </div>
    );
  }

}
export default withRouter(EditBook);