import React from 'react'
import { Menu } from 'semantic-ui-react'
import 'react-toastify/dist/ReactToastify.css'
import { toast } from 'react-toastify';
import {
    withRouter
  } from "react-router-dom";

class MyMenu extends React.Component{

    constructor(props){
        super(props);
        this.state = {
            activeItem: 'home',
            menu: ['home', 'books', 'read-list', 'favorite-list'],
            isAdmin: false,
        };
    }

  componentDidMount = () => { 
    const path = this.props.location.pathname;


    if(!localStorage.getItem("isAuthenticated")){
        this.props.history.push("/");
    }

    else if(localStorage.getItem("isAdmin")){
        let active = "home";
        if(path === "/users"){
            active =  "users";
        }
        else if(path === "/books"){
            active = "books";
        }
        else if(path === "/authors"){
            active = "authors";
        }
        this.setState({menu: ['home', 'users', 'books', 'authors'], isAdmin: true, activeItem: active});
    }
    else{
        if(path === "/books"){
            this.setState({activeItem: "books"});
        }
        else if(path === "/favorites"){
          this.setState({activeItem: "favorite-list"});
        }
        else if(path === "/read-list"){
          this.setState({activeItem: "read-list"});
        }
    }

  }

  logout = () => {
    fetch("http://localhost:8081/logout" , {
        method: "GET", 
    })
    .then((r) => {
        if(r.ok){
          toast.success("You are logged out. Redirecting to login page.");
          return r;
        }
        if(r.status === 401 || r.status === 403 || r.status === 500){
          return Promise.reject(new Error(r.status));
        }
      })
      .catch((e) => {
        toast.error(e.message);
      });
  }
  

  render() {
    const { activeItem, menu, isAdmin} = this.state;

    return (
      <div>
        <Menu pointing secondary size= "huge">
          <Menu.Item
            name={menu[0]}
            active={activeItem === menu[0]}
            onClick={ () => {
                this.setState({ activeItem: menu[0] });
                this.props.history.push("/home") ; }
            }
          />
          <Menu.Item
            name={menu[1]}
            active={activeItem === menu[1]}
            onClick={ () => {
                this.setState({ activeItem: menu[1] });
                if(isAdmin === true)
                  this.props.history.push("/users") ;
                else{
                  this.props.history.push("/books" );
                  window.location.reload();                     
                }
            }}
          />
          <Menu.Item
            name={menu[2]}
            active={activeItem === menu[2]}
            onClick={ () => {
                this.setState({ activeItem: menu[2] });
                isAdmin === true ? this.props.history.push("/books") 
                                    : this.props.history.push("/read-list");
                if(isAdmin === true)
                  this.props.history.push("/books") ;
                else{
                  this.props.history.push("/read-list" );
                  window.location.reload();
              }
            }}
          />
          <Menu.Item
            name={menu[3]}
            active={activeItem === menu[3]}
            onClick = {() => {
                this.setState({ activeItem: menu[3] });
                
                if(isAdmin === true)
                  this.props.history.push("/authors") ;
                else{
                  this.props.history.push("/favorites" );
                  window.location.reload();
                }
              }}
          />
          <Menu.Menu position='right'>
            <Menu.Item
              name='logout'
              active={activeItem === 'logout'}
              onClick={() =>{
                this.setState({activeItem: "logout"});
                this.logout();    
                localStorage.removeItem("isAdmin");
                localStorage.removeItem("isAuthenticated");
                setTimeout(() => {
                    this.props.history.push("/");}, 3000);

              }}
            />
          </Menu.Menu>
          
        </Menu>

      </div>
    );
  }
}
export default withRouter(MyMenu);
