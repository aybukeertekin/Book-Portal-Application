package tr.com.obss.ertekin.aybuke.springproject.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.CurrentSecurityContext;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import tr.com.obss.ertekin.aybuke.springproject.entity.User;
import tr.com.obss.ertekin.aybuke.springproject.model.user.UserDTO;
import tr.com.obss.ertekin.aybuke.springproject.model.user.UserUpdateDTO;
import tr.com.obss.ertekin.aybuke.springproject.service.UserService;

import javax.validation.Valid;
import java.io.IOException;
import java.security.Principal;
import java.util.Optional;

@RestController
@RequestMapping("/book-portal/user")
public class UserController {

    private UserService userService;

    @Autowired
    public UserController(UserService userService) {
        this.userService = userService;
    }

    private static final Logger LOGGER = LoggerFactory.getLogger(UserController.class);

    @GetMapping("")
    @ResponseBody
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    public ResponseEntity<?> get(@RequestParam(name="pageNumber", defaultValue = "0") int pageNumber) {
        return ResponseEntity.ok(userService.findAllUsers(pageNumber));
    }

    @GetMapping("/{id}")
    @ResponseBody
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    public ResponseEntity<?> get(@PathVariable long id) {
        Optional<User> optionalUser = userService.findById(id);
        if(optionalUser.isPresent()){
            return ResponseEntity.ok(optionalUser.get());
        }
        throw new IllegalArgumentException("We could not find user.");
    }

    @PutMapping("/{id}")
    @ResponseBody
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    public ResponseEntity<?> put(@PathVariable long id, @Valid @RequestBody UserUpdateDTO user){
        tr.com.obss.ertekin.aybuke.springproject.entity.User newUser = userService.update(id, user);
        return ResponseEntity.ok(newUser);
    }

    @GetMapping("/delete/{id}")
    @ResponseBody
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    public ResponseEntity<?> delete(@PathVariable long id){
        tr.com.obss.ertekin.aybuke.springproject.entity.User newUser = userService.delete(id);
        return ResponseEntity.ok(newUser);
    }

    @PostMapping
    @ResponseBody
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    public ResponseEntity<?> post(@Valid UserDTO user) {
        LOGGER.info("{}, {}", user.getUsername(), user.getPassword());
        try {
            return ResponseEntity.ok(userService.saveUser(user));
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    @PostMapping("/add-favorites/{book_id}")
    @ResponseBody
    @PreAuthorize("hasRole('ROLE_USER')")
    public ResponseEntity<?> addBookToFavoriteList(@CurrentSecurityContext(expression = "authentication.principal")Principal principal,
                                                   @PathVariable long book_id) {
        String username = principal.getName();
        boolean added = userService.addBookFavorites(book_id, username);
        if(added)
            return ResponseEntity.ok("Book is added to your favorites.");
        else
            return ResponseEntity.ok("Book is removed from your favorites.");
    }

    @PostMapping("/add-read-list/{book_id}")
    @ResponseBody
    @PreAuthorize("hasRole('ROLE_USER')")
    public ResponseEntity<?> addBookToReadList(@CurrentSecurityContext(expression = "authentication.principal")Principal principal,
                                                   @PathVariable long book_id) {
        String username = principal.getName();
        boolean added = userService.addBookToReadList(book_id, username);
        if(added)
            return ResponseEntity.ok("Book is added to your read list.");
        else
            return ResponseEntity.ok("Book is removed from your read list.");
    }

    @GetMapping("/search")
    @ResponseBody
    public ResponseEntity<?> search(@RequestParam(name="username", defaultValue = "") String username) {
        return ResponseEntity.ok(userService.findByUsersWithSimilarName(username));
    }

    @GetMapping("/favorites")
    @ResponseBody
    public ResponseEntity<?> getFavorites(@CurrentSecurityContext(expression = "authentication.principal")Principal principal,
                                          @RequestParam(name="pageNumber", defaultValue = "0") int pageNumber){
        return ResponseEntity.ok(userService.getFavoritesByUsername(principal.getName(), pageNumber));
    }

    @GetMapping("/read-list")
    @ResponseBody
    public ResponseEntity<?> getReadList(@CurrentSecurityContext(expression = "authentication.principal")Principal principal,
                                                                @RequestParam(name="pageNumber", defaultValue = "0") int pageNumber){
        return ResponseEntity.ok(userService.getReadListByUsername(principal.getName(), pageNumber));
    }


    @GetMapping("/all-favorites")
    @ResponseBody
    public ResponseEntity<?> getFavorites(@CurrentSecurityContext(expression = "authentication.principal")Principal principal){
        return ResponseEntity.ok(userService.getFavorites(principal.getName()));
    }

    @GetMapping("/all-read-list")
    @ResponseBody
    public ResponseEntity<?> getReadList(@CurrentSecurityContext(expression = "authentication.principal")Principal principal){
        return ResponseEntity.ok(userService.getReadList(principal.getName()));
    }
}
