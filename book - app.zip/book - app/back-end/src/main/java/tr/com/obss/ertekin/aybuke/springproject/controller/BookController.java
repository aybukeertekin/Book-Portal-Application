package tr.com.obss.ertekin.aybuke.springproject.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import tr.com.obss.ertekin.aybuke.springproject.entity.Book;
import tr.com.obss.ertekin.aybuke.springproject.model.book.BookDTO;
import tr.com.obss.ertekin.aybuke.springproject.model.book.BookUpdateDTO;
import tr.com.obss.ertekin.aybuke.springproject.service.BookService;

import javax.validation.Valid;
import java.util.List;
import java.util.Optional;


@RestController
@RequestMapping("/book-portal/book")
public class BookController {
    private BookService bookService;

    @Autowired
    public BookController(BookService bookService) {
        this.bookService = bookService;
    }

    @GetMapping
    public ResponseEntity<?> get(@Valid @RequestParam(name = "pageNumber", defaultValue = "0") int pageNumber) {
        return ResponseEntity.ok(bookService.findAll(pageNumber));
    }

    @GetMapping("/search/{identifier}") //searche gerek yok
    public ResponseEntity<List<Book>> get(
                                          @PathVariable(name="identifier") String searchBy) {
            return ResponseEntity.ok(bookService.findByName(searchBy));
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> get(@PathVariable long id) {
        Optional<Book> optionalBook = bookService.findById(id);
        if(optionalBook.isPresent()){
            return ResponseEntity.ok(optionalBook);
        }
        throw new IllegalArgumentException("We could not find the book.");
    }


    @GetMapping("/delete/{id}") //delete sil
    @ResponseBody
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    public ResponseEntity<?> delete(@PathVariable long id){
        Book newBook = bookService.delete(id);
        return ResponseEntity.ok(newBook);
    }

    @PutMapping("/{id}")
    @ResponseBody
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    public ResponseEntity<?> put(@PathVariable long id, @Valid @RequestBody BookUpdateDTO book){
        return ResponseEntity.ok(bookService.update(id, book));
    }

    @PostMapping
    @ResponseBody
    @PreAuthorize("hasRole('ROLE_ADMIN')")
    public ResponseEntity<?> post(@Valid @RequestBody BookDTO book) {
        return ResponseEntity.ok(bookService.saveBook(book));
    }
}
