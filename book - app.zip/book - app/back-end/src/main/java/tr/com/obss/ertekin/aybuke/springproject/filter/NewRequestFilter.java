package tr.com.obss.ertekin.aybuke.springproject.filter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.CommonsRequestLoggingFilter;
import tr.com.obss.ertekin.aybuke.springproject.controller.UserController;

import javax.servlet.http.HttpServletRequest;

@Component
public class NewRequestFilter extends CommonsRequestLoggingFilter {
    private static final Logger LOGGER = LoggerFactory.getLogger(UserController.class);

    @Override
    protected boolean shouldLog(HttpServletRequest request) {
        return request.getRequestURI().contains("/api");
    }

    @Override
    protected void beforeRequest(HttpServletRequest request, String message) {
        LOGGER.info("Request filter has begun URI: {}, method:{}", request.getRequestURI(), request.getMethod());
    }

    @Override
    protected void afterRequest(HttpServletRequest request, String message) {
        LOGGER.info("Request filter has finished URI: {}, method:{}", request.getRequestURI(), request.getMethod());
    }


}
