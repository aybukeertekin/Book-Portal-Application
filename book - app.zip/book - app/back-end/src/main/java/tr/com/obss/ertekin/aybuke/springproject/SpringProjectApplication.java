package tr.com.obss.ertekin.aybuke.springproject;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import tr.com.obss.ertekin.aybuke.springproject.interceptor.MyInterceptor;

@SpringBootApplication
public class SpringProjectApplication implements WebMvcConfigurer {

	@Autowired
	private MyInterceptor requestInInterceptor;

	public static void main(String[] args) {
		SpringApplication.run(SpringProjectApplication.class, args);
	}

	@Override
	public void addInterceptors(InterceptorRegistry registry) {
		registry.addInterceptor(requestInInterceptor);
	}
}
