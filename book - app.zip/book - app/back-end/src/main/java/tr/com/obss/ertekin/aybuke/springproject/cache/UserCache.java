package tr.com.obss.ertekin.aybuke.springproject.cache;

import tr.com.obss.ertekin.aybuke.springproject.model.user.UserDTO;
import java.util.Map;

public interface UserCache {

    void put(UserDTO user);
    Map<String, UserDTO> getMap();

}
