package tr.com.obss.ertekin.aybuke.springproject.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Getter
@Setter
@MappedSuperclass
public class EntityBase implements Serializable {
    private static final long SerialVersionUID = 1L;

    @Id
    @Column(name = "ID")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @Column(name = "CREATE_DATE")
    private Date createDate;

    @Column(name = "UPDATE_DATE")
    private Date updateDate;

    @Column(name = "ACTIVE")
    private boolean active;

    @Column(name = "OPERATION_TYPE")
    private String operationType;


    @PrePersist
    public void onPrePersist(){
        this.setOperationType("SAVE");
        this.setCreateDate(new Date());
        this.setUpdateDate(new Date());
        this.setActive(true);
    }

    @PreUpdate
    public void onPreUpdate(){
        this.setOperationType("UPDATE");
        this.setUpdateDate(new Date());
    }

    @PreRemove
    public void onPreRemove(){
        this.setOperationType("DELETE");
        this.setUpdateDate(new Date());
    }

    @Override
    public boolean equals(Object obj) {
        if(obj instanceof EntityBase) {
            EntityBase entityBase = (EntityBase) obj;
            return entityBase.id == this.id ;
        }
        return false;
    }
}
