package tr.com.obss.ertekin.aybuke.springproject.service;

import org.apache.tomcat.util.codec.binary.Base64;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import tr.com.obss.ertekin.aybuke.springproject.Constants;
import tr.com.obss.ertekin.aybuke.springproject.cache.UserCache;
import tr.com.obss.ertekin.aybuke.springproject.entity.Book;
import tr.com.obss.ertekin.aybuke.springproject.entity.Role;
import tr.com.obss.ertekin.aybuke.springproject.entity.User;
import tr.com.obss.ertekin.aybuke.springproject.model.MyUserDetails;
import tr.com.obss.ertekin.aybuke.springproject.model.user.UserDTO;
import tr.com.obss.ertekin.aybuke.springproject.model.user.UserUpdateDTO;
import tr.com.obss.ertekin.aybuke.springproject.repository.BookRepository;
import tr.com.obss.ertekin.aybuke.springproject.repository.UserRepository;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;
import java.util.Optional;

@Service
public class UserService implements UserDetailsService {
    public final static String USER_ROLE_NAME = "USER_ROLE";

    @Autowired
    private ApplicationContext context;

    @Autowired
    @Qualifier("singletonCache")
    private UserCache userCache;


    @Autowired
    private UserRepository userRepository;


    @Autowired
    private PasswordEncoder encoder;

    @Bean
    public PasswordEncoder passwordEncoder(){
        return new BCryptPasswordEncoder();
    }


    /*
        Checks if there is any user with the same username.
        If there is not any user adds user to the system.
     */
    public User saveUser(UserDTO user) throws IOException {
        Optional<User> userWithSameUsername = userRepository.findByUsername(user.getUsername());
        if(userWithSameUsername.isPresent()){
            throw new IllegalArgumentException("Username is reserved. Please use another one");
        }
        User savedUser = new User();
        savedUser.setUsername(user.getUsername());
        savedUser.setPassword(encoder.encode(user.getPassword()));
        savedUser.setRole(Role.ROLE_USER);
        savedUser.setName(user.getName());
        savedUser.setSurname(user.getSurname());
        return userRepository.save(savedUser);
    }

    private static byte[] readBytesFromFile(File file) {

        FileInputStream fileInputStream = null;
        byte[] bytesArray = null;

        try {
            bytesArray = new byte[(int) file.length()];

            //read file into bytes[]
            fileInputStream = new FileInputStream(file);
            fileInputStream.read(bytesArray);

        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (fileInputStream != null) {
                try {
                    fileInputStream.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

        }
        return bytesArray;
    }

    /*
        Finds all users.
    */
    public Page<User> findAllUsers(int pageNumber){
        Pageable paged = PageRequest.of(pageNumber, Constants.PAGE_SIZE, Sort.by("username"));
        return userRepository.findAll(paged);
    }

    /*
        Finds user with given id.
        Throws exception if there is not any user like this.
    */
    public Optional<User> findById(long id){
        Optional<User> user = userRepository.findById(id);
        if(user.isPresent())
            return user;
        throw new IllegalArgumentException("There is no such user");
    }

    /*
        Find an active end user with given username.
    */
    public Optional<User> findByUsername(String username){
        return userRepository.findByUsername(username);
    }

    /*
        Finds end user with a username similar to given name.
        Throws exception if there is not any user like this.
    */
    public List<User> findByUsersWithSimilarName(String username){
        List<User> users = userRepository.findByUsernameContainingOrderByIdDesc(username);
        return users;
    }


    /*
        Update the user with the given id.
    */
    public User update(long id, UserUpdateDTO user){
        Optional<User>  updatedUser = userRepository.findById(id);
        if(updatedUser.isPresent() ){
            User newUser = updatedUser.get();
            if(newUser.isActive()) {
                newUser.setPassword(encoder.encode(user.getPassword()));
                return userRepository.save(newUser);
            }
        }
        throw new IllegalArgumentException("User is not valid");
    }


    /**
        Change active state of the user with given id.
    */
    public User delete(long id){
        Optional<User>  updatedUser = userRepository.findById(id);
        if(updatedUser.isPresent()){
            User newUser = updatedUser.get();
            newUser.setActive(!newUser.isActive());
            return userRepository.save(newUser);
        }
        throw new IllegalArgumentException("User is not valid");
    }


    @Override
    public UserDetails loadUserByUsername(String s) throws UsernameNotFoundException {
        Optional<User> user = userRepository.findByUsername(s);
        if(user.isPresent()){
            return new MyUserDetails(user.get());
        }
        throw new UsernameNotFoundException("We could not find the user.");
    }


    @Autowired
    private BookRepository bookRepository;

    /**
     * Find book and user with given ids.
     * If they are not present, throw exception.
     */
    public boolean addBookToReadList(long bookId, String username){
        Optional<User>  user = userRepository.findByUsername(username);
        Optional<Book> book = bookRepository.findById(bookId);
        if(user.isPresent() && book.isPresent()){
            User userUpdated = user.get();
            Book bookUpdated = book.get();
            if(userUpdated.getReadList().contains(book.get())){
                userUpdated.getReadList().remove(bookUpdated);
                bookUpdated.getUsersRead().remove(userUpdated);
                userRepository.save(userUpdated);
                bookRepository.save(bookUpdated);
                return false;
            }
            userUpdated.getReadList().add(bookUpdated);
            bookUpdated.getUsersRead().add(userUpdated);
            userRepository.save(userUpdated);
            bookRepository.save(bookUpdated);
            return true;
        }
        throw new IllegalArgumentException("User or book is not valid");
    }




    public boolean addBookFavorites(long bookId, String username){
        Optional<User>  user = userRepository.findByUsername(username);
        Optional<Book> book = bookRepository.findById(bookId);
        if(user.isPresent() && book.isPresent()){
            User userUpdated = user.get();
            Book bookUpdated = book.get();
            if(userUpdated.getFavoriteBooks().contains(bookUpdated)){
                userUpdated.getFavoriteBooks().remove(bookUpdated);
                bookUpdated.getUsersLiked().remove(userUpdated);
                userRepository.save(userUpdated);
                bookRepository.save(bookUpdated);
                return false;
            }
            userUpdated.getFavoriteBooks().add(bookUpdated);
            bookUpdated.getUsersLiked().add(userUpdated);
            userRepository.save(userUpdated);
            bookRepository.save(bookUpdated);
            return true;
        }
        throw new IllegalArgumentException("User or book is not valid");
    }

    /**
     * Finds favorites of a user with given username.
     * @param
     * @return
     */
    public Page<Book> getReadListByUsername(String username, int pageNumber) {
        Optional<User> user = userRepository.findByUsername(username);
        Pageable paged = PageRequest.of(pageNumber, Constants.PAGE_SIZE, Sort.by("title"));
        if(user.isPresent())
            return bookRepository.findBooksByActiveTrueAndUsersRead_UsernameIs(username, paged);
        throw new UsernameNotFoundException("We could not find the user");
    }


    public Page<Book> getFavoritesByUsername(String username, int pageNumber) {
        Optional<User> user = userRepository.findByUsername(username);
        Pageable paged = PageRequest.of(pageNumber, Constants.PAGE_SIZE, Sort.by("title"));
        if(user.isPresent())
            return bookRepository.findBooksByActiveTrueAndUsersLiked_UsernameIs(username, paged);
        throw new UsernameNotFoundException("We could not find the user");
    }

    /**
     * Finds favorites of a user with given username.
     * @param
     * @return
     */
    public List<Book> getReadList(String username) {
        Optional<User> user = userRepository.findByUsername(username);
        if(user.isPresent())
            return bookRepository.findBooksByActiveTrueAndUsersRead_UsernameIs(username);
        throw new UsernameNotFoundException("We could not find the user");
    }


    public List<Book> getFavorites(String username) {
        Optional<User> user = userRepository.findByUsername(username);
        if(user.isPresent())
            return bookRepository.findBooksByActiveTrueAndUsersLiked_UsernameIs(username);
        throw new UsernameNotFoundException("We could not find the user");
    }

}
