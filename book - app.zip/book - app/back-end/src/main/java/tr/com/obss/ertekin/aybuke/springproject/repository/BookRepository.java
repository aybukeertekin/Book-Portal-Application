package tr.com.obss.ertekin.aybuke.springproject.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import tr.com.obss.ertekin.aybuke.springproject.entity.Book;

import java.util.List;
import java.util.Optional;

@Repository
public interface BookRepository extends JpaRepository<Book, Long> {
    Page<Book> findAllByActiveTrue(Pageable paged);
    List<Book> findBooksByActiveTrueAndTitleContaining(String name);
    Optional<Book> findBookByActiveTrueAndIsbn(long ISBN);
    Page<Book> findBooksByActiveTrueAndUsersRead_UsernameIs(String name, Pageable paged);
    Optional<Book> findBookByActiveTrueAndId(long id);
    Optional<Book> findBookByIsbn(long ISBN);
    Page<Book> findBooksByActiveTrueAndUsersLiked_UsernameIs(String username, Pageable paged);

    List<Book> findBooksByActiveTrueAndUsersLiked_UsernameIs(String username);
    List<Book> findBooksByActiveTrueAndUsersRead_UsernameIs(String name);

    List<Book> findAll();
}
