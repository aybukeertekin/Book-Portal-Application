package tr.com.obss.ertekin.aybuke.springproject.entity;

public enum Role{
    ROLE_USER, ROLE_ADMIN
}