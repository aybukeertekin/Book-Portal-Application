package tr.com.obss.ertekin.aybuke.springproject.model.book;

import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.Digits;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Getter
@Setter
public class BookDTO extends BookUpdateDTO {

    @NotNull
    private long ISBN;
}
