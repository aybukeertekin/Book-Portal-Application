package tr.com.obss.ertekin.aybuke.springproject.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import tr.com.obss.ertekin.aybuke.springproject.Constants;
import tr.com.obss.ertekin.aybuke.springproject.entity.Book;
import tr.com.obss.ertekin.aybuke.springproject.model.book.BookDTO;
import tr.com.obss.ertekin.aybuke.springproject.model.book.BookUpdateDTO;
import tr.com.obss.ertekin.aybuke.springproject.repository.BookRepository;

import java.util.List;
import java.util.Optional;

@Service
public class BookService {

    @Autowired
    BookRepository bookRepository;

    /*
        Finds books with a title similar to given name and returns found books.
        Throws IllegalArgs exception if any book is not found.
    */
    public List<Book> findByName(String name) {
        List<Book> books = bookRepository.findBooksByActiveTrueAndTitleContaining(name);
        return books;
    }

    /*
        Finds book with the given ISBN number.
        Throws IllegalArgs exception if any book is not found.
     */
    public Optional<Book> findByISBN(int ISBN) {
        Optional<Book> book = bookRepository.findBookByActiveTrueAndIsbn(ISBN);
        if (book.isPresent()) {
            return book;
        }
        throw new IllegalArgumentException("We do not have any book with given ISBN number");
    }

    /*
        Finds book with the given id number.
        Throws IllegalArgs exception if any book is not found.
    */
    public Optional<Book> findById(long id) {
        Optional<Book> book = bookRepository.findBookByActiveTrueAndId(id);
        if (book.isPresent()) {
            return book;
        }
        throw new IllegalArgumentException("We do not have this book.");
    }


    /*
        Returns all active books in the system.
    */
    public Page<Book> findAll(int pageNumber) {
        Pageable paged = PageRequest.of(pageNumber, Constants.PAGE_SIZE, Sort.by("title"));
        return bookRepository.findAllByActiveTrue(paged);
    }

    /*
        Makes an active book inactive. Returns updated book.
        If there is no such book throws exception.
     */
    public Book delete(long id) {
        Optional<Book>  updatedBook = bookRepository.findById(id);
        if(updatedBook.isPresent()){
            Book newBook = updatedBook.get();
            newBook.setActive(!newBook.isActive());
            return bookRepository.save(newBook);
        }
        throw new IllegalArgumentException("Book is not valid");
    }

    /*
        Updates book's title, author, and publisher.
        ISBN number cannot be changed.
        Throws exception if book is not found in the system.
     */
    public Book update(long id, BookUpdateDTO book) {
        Optional<Book>  updatedBook = bookRepository.findBookByActiveTrueAndId(id);
        if(updatedBook.isPresent()){
            Book newBook = updatedBook.get();
            newBook.setTitle(book.getTitle());
            newBook.setAuthor(book.getAuthor());
            return bookRepository.save(newBook);
        }
        throw new IllegalArgumentException("Book is not valid");
    }

    /*
        Save book to the system.
        If there is already a book with the same ISBN number checks its active state and
        updates it.
     */
    public Book saveBook(BookDTO book) {
        Optional<Book> bookWithSameISBN = bookRepository.findBookByIsbn(book.getISBN());
        Book savedBook;
        if(bookWithSameISBN.isPresent()){
            savedBook = bookWithSameISBN.get();
            savedBook.setActive(true);
        }else{
            savedBook = new Book();
            savedBook.setIsbn(book.getISBN());
        }
        savedBook.setAuthor(book.getAuthor());
        savedBook.setTitle(book.getTitle());
        savedBook.setPublicationYear(book.getYear());
        savedBook.setPublisher(book.getPublisher());
        savedBook.setType(book.getType());
        return bookRepository.save(savedBook);
    }
}
