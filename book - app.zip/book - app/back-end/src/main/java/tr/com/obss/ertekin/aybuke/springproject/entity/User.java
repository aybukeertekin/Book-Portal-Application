package tr.com.obss.ertekin.aybuke.springproject.entity;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.LazyCollection;
import org.hibernate.annotations.LazyCollectionOption;
import tr.com.obss.ertekin.aybuke.springproject.Constants;

import javax.persistence.*;
import java.awt.*;
import java.util.Set;

@Getter
@Setter
@Entity
@Table(name="USER_ACCOUNT")
public class User extends EntityBase{
    private static final long SerialVersionUID = 1L;

    @Column(name = "USERNAME", length = 255, unique = true)
    private String username;

    @Column(name = "PASSWORD", length = 255)
    private String password;

    @Column(name = "NAME", length = 255)
    private String name;

    @Column(name = "SURNAME", length = 255)
    private String surname;

    @Column(name="ROLE")
    private Role role;

    @Column(name="IMAGE")
    private byte[] image;


    @ManyToMany(cascade = CascadeType.MERGE)
    @JoinTable(name="USER_READ_LIST",
            joinColumns = {@JoinColumn(name="USER_ID", referencedColumnName = "ID")},
            inverseJoinColumns = {@JoinColumn(name="BOOK_ID", referencedColumnName = "ID")})
    @JsonManagedReference
    private Set<Book> readList;

    @ManyToMany(cascade = CascadeType.MERGE)
    @JoinTable(name="USER_FAVORITES",
            joinColumns = {@JoinColumn(name="USER_ID", referencedColumnName = "ID")},
            inverseJoinColumns = {@JoinColumn(name="BOOK_ID", referencedColumnName = "ID")})
    @JsonManagedReference
    private Set<Book> favoriteBooks;



}
