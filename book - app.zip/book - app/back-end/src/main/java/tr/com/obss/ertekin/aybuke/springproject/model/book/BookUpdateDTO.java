package tr.com.obss.ertekin.aybuke.springproject.model.book;

import lombok.Getter;
import lombok.Setter;
import tr.com.obss.ertekin.aybuke.springproject.entity.Type;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.time.Year;

@Getter
@Setter
public class BookUpdateDTO{

    @NotBlank
    @Size(max = 255, min = 3, message = "Please send a valid title")
    private String title;

    @NotBlank
    @Size(max = 255, min = 3, message = "Please send a valid author")
    private String author;

    @NotBlank
    @Size(max = 255, min = 3, message = "Please send a valid publisher")
    private String publisher;

    @NotNull
    private Year year;

    @NotNull
    private Type type;
}
