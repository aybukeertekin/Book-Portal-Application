package tr.com.obss.ertekin.aybuke.springproject.cache;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import tr.com.obss.ertekin.aybuke.springproject.model.user.UserDTO;
import javax.annotation.PostConstruct;
import java.util.HashMap;
import java.util.Map;

@Component("prototypeCache")
@Scope("prototype")
public class UserCachePrototype implements UserCache{

    private Map<String, UserDTO> users;

    @PostConstruct
    public void init(){
        users = new HashMap<>();
    }

    @Override
    public void put(UserDTO user) {
        users.put(user.getUsername(), user);
    }

    @Override
    public Map<String, UserDTO> getMap() {
        return users;
    }
}
