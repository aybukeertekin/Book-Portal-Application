package tr.com.obss.ertekin.aybuke.springproject;

public interface Constants {
    public static final int PAGE_SIZE = 4;
    public static String user = "ROLE_USER";
    public static String admin = "ROLE_ADMIN";
}
