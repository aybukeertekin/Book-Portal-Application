package tr.com.obss.ertekin.aybuke.springproject.entity;


import com.fasterxml.jackson.annotation.JsonBackReference;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
import java.time.Year;
import java.util.Set;

@Getter
@Setter
@Entity
@Table(name = "BOOKS")
public class Book extends EntityBase{
    private static final long SerialVersionUID = 1L;

    @Column(name = "ISBN", unique = true)
    private long isbn;

    @Column(name = "TITLE")
    private String title;

    @Column(name = "AUTHOR")
    private String author;

    @Column(name = "PUBLISHER")
    private String publisher;

    @Column(name = "TYPE")
    private Type type;

    @Column(name = "YEAR")
    private Year publicationYear;

    @ManyToMany(mappedBy = "readList")
    @JsonBackReference
    private Set<User> usersRead;

    @ManyToMany(mappedBy = "favoriteBooks")
    @JsonBackReference
    private Set<User> usersLiked;

}
