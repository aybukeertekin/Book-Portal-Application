package tr.com.obss.ertekin.aybuke.springproject.model.user;

import com.sun.xml.bind.v2.runtime.unmarshaller.Base64Data;
import lombok.Getter;
import lombok.Setter;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import java.io.File;

@Getter
@Setter
public class UserUpdateDTO {
    @NotBlank
    @Size(max = 255, min = 3, message = "Please send a valid password")
    private String password;

    @NotBlank
    @Size(max = 255, min = 3, message = "Please send a valid name")
    private String name;

    @NotBlank
    @Size(max = 255, min = 3, message = "Please send a valid surname")
    private String surname;

}
