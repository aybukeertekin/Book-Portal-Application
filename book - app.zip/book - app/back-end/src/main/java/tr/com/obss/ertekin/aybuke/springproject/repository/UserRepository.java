package tr.com.obss.ertekin.aybuke.springproject.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import tr.com.obss.ertekin.aybuke.springproject.entity.User;

import java.util.List;
import java.util.Optional;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {

    List<User> findByUsernameContainingOrderByIdDesc(String name);
    List<User> findByRole(String roleName);
    Page<User> findByRole(String roleName, Pageable page);
    Optional<User> findByUsername(String username);


    /**
    @Query("select u from User u where u.id=:id")
    Optional<User> getByActiveTrueAndId(long id);

    @Query(value = "select * from USER_ACCOUNT u where u.id=:id", nativeQuery = true)
    Optional<User> getByIdNative(long id);
    */
}
