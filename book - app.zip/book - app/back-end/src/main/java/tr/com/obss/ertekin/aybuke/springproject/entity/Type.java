package tr.com.obss.ertekin.aybuke.springproject.entity;


public enum Type{
    NOVEL,
    POETRY,
    HISTORY,
    BIOGRAPHY,
    TRAVEL,
    SCIENCE,
    HUMOR,
    LITERARY,
    ART,
    MEMORY
}